1. chmod a+x bin/*
2. cp bin/* /usr/bin
3. cp systemd/* /lib/systemd/system/